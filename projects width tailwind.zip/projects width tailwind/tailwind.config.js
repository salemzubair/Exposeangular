/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,ts}",
  ],
  theme: {
    screens: {

      'xs': { 'min': '320px', 'max': '374px' },

      'sm': { 'min': '375px', 'max': '424px' },

      'smd': { 'min': '425px', 'max': '767px' },

      'md': { 'min': '768px', 'max': '1023px' },

      'lg': { 'min': '1024px', 'max': '1279px' },

      'xl': { 'min': '1280px', 'max': '1900px' }

    },
    extend: {
      fontFamily: {
        'mycustomfont': ['poppins', 'sans-serif'],
      }
    },
  },
  plugins: [],
}

